package com.cg.registration.bean;

public class StudentBean {
	private String studentName;
	private String studentPass;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentPass() {
		return studentPass;
	}
	public void setStudentPass(String studentPass) {
		this.studentPass = studentPass;
	}
	@Override
	public String toString() {
		return "StudentBean [studentName=" + studentName + ", studentPass=" + studentPass + "]";
	}
	
	
	
	
}
