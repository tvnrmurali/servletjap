package com.cg.registration.exception;

public class CustomExceptiom extends Exception {

	public CustomExceptiom() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
