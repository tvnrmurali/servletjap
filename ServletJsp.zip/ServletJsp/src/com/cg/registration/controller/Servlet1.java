package com.cg.registration.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.registration.bean.StudentBean;
import com.cg.registration.exception.CustomExceptiom;


@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response); 
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		StudentBean studentBean = new StudentBean();
		
		studentBean.setStudentName(request.getParameter("username"));
		studentBean.setStudentPass(request.getParameter("password"));
		
		request.setAttribute("name", studentBean.getStudentName());
		request.setAttribute("pass", studentBean.getStudentPass());
		try {
			HttpSession session = request.getSession();
			
			if(session.isNew())
			{
				session.setAttribute("userName", studentBean);
			}
			else
			{
				throw new CustomExceptiom();
			}
		} catch (CustomExceptiom ce) {
			// TODO: handle exception
			System.out.println("Session creation error");
		}
		
		response.sendRedirect("Success.html");
	
	}

}
